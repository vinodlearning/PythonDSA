INPUT | CORRECTED_INPUT | QUERY_TYPE | ACTION_TYPE | DISPLAY_ENTITIES | FILTER_ENTITIES
==================================================================================
Tell me how to create a contract | Tell me how to create a contract | CONTRACTS | contracts_list | CONTRACT_NAME | 
How to create contarct? | How to create contarct? | HELP | HELP_CONTRACT_CREATE_USER |  | 
Steps to create contract | Steps to create contract | HELP | HELP_CONTRACT_CREATE_USER |  | 
Can you show me how to make a contract? | Can you show me how to make a contract? | CONTRACTS | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
What's the process for contract creation? | what's the process for contract creation | CONTRACTS | contracts_list | CONTRACT_NAME | 
I need guidance on creating a contract | I need guidance on creating a contract | HELP | HELP_CONTRACT_CREATE_USER |  | 
Walk me through contract creation | Walk me through contract creation | HELP | HELP_CONTRACT_CREATE_USER |  | 
Explain how to set up a contract | Explain how to set up a contract | HELP | HELP_CONTRACT_CREATE_USER |  | 
Instructions for making a contract | instructions for make a contract | HELP | HELP_CONTRACT_CREATE_USER |  | 
Need help understanding contract creation | Need help understanding contract creation | HELP | HELP_CONTRACT_CREATE_USER |  | 
Create a contract for me | create a contract for me | HELP | HELP_CONTRACT_CREATE_USER |  | 
Can you create contract? | Can you create contract? | HELP | HELP_CONTRACT_CREATE_BOT |  | 
Please make a contract | Please make a contract | HELP | HELP_CONTRACT_CREATE_BOT |  | 
Generate a contract | Generate a contract | HELP | HELP_CONTRACT_CREATE_BOT |  | 
I need you to create a contract | I need you to create a contract | HELP | HELP_CONTRACT_CREATE_BOT |  | 
Set up a contract | Set up a contract | HELP | HELP_CONTRACT_CREATE_USER |  | 
Make me a contract | Make me a contract | HELP | HELP_CONTRACT_CREATE_BOT |  | 
Initiate contract creation | Initiate contract creation | HELP | HELP_CONTRACT_CREATE_BOT |  | 
Start a new contract | Start a new contract | HELP | HELP_CONTRACT_CREATE_BOT |  | 
Could you draft a contract? | Could you draft a contract? | HELP | HELP_CONTRACT_CREATE_BOT |  | 
How do I create a contract? | How do I create a contract? | HELP | HELP_CONTRACT_CREATE_USER |  | 
What are the steps to make a contract? | What are the steps to make a contract? | CONTRACTS | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Can you explain how to create a contract? | Can you explain how to create a contract? | HELP | HELP_CONTRACT_CREATE_USER |  | 
Create a contract for me | create a contract for me | HELP | HELP_CONTRACT_CREATE_USER |  | 
Generate contract now | Generate contract now | HELP | HELP_CONTRACT_CREATE_USER |  | 
Make me a contract please | Make me a contract please | HELP | HELP_CONTRACT_CREATE_BOT |  | 
How too creat a contract? | How too creat a contract? | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Steps for makeing a contrakt | steps for makeing a contrakt | HELP | HELP_CONTRACT_CREATE_USER |  | 
Creat a contract pls | Creat a contract pls | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Plz make contract | Plz make contract | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Need 2 create cntract | Need 2 create cntract | CONTRACTS | contracts_search | AWARD_NUMBER | 
How 2 make contract? | How 2 make contract? | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
How create contract? | How create contract? | HELP | HELP_CONTRACT_CREATE_USER |  | 
Steps contract creation | Steps contract creation | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Make contract | Make contract | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Contract how make? | Contract how make? | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Creation steps contract | Creation steps contract | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
For me contract create | for me contract create | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
HOW TO CREATE contract? | HOW TO CREATE contract? | HELP | HELP_CONTRACT_CREATE_USER |  | 
create...CONTRACT! | create...CONTRACT! | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
contract (how to)? | contract (how to)? | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
contractcreation | contractcreation | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
contract     make | contract     make | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
contract; creation | contract; creation | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Need contract | Need contract | CONTRACTS | contracts_list | CONTRACT_NAME | 
Create? | Create? | CONTRACTS | contracts_search | AWARD_NUMBER | 
How? | How? | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER | 
Generating contract | Generating contract | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Made me contract | Made me contract | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Creating how? | Creating how? | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER | 
4 contract creation | for contract creation | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
Need contract ASAP | Need contract ASAP | CONTRACTS | contracts_list | CONTRACT_NAME | 
Contract steps 101 | Contract steps 101 | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
contract@create | contract@create | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
#createcontract | #createcontract | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
contract*creation*help | contract*creation*help | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
ctrct | ctrct | CONTRACTS | contracts_list | AWARD_NUMBER | 
mk | mk | CONTRACTS | contracts_search | AWARD_NUMBER | 
how | how | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER | 
Could you possibly be so kind as to tell me the exact step-by-step process for creating a new contractual agreement in this system? | could you possibly be so kind as to tell me the exact step by step process for create a new contractual agreement in this system | CONTRACTS | contracts_by_filter | CONTRACT_NAME | 
I would really appreciate if you could immediately generate for me a complete contract document with all standard terms and conditions included | i would really appreciate if you could now generate for me a complete contract document with all standard terms and conditions included | HELP | HELP_CONTRACT_CREATE_USER |  | 
What is the effective date for contarct 123456? | what is the effective date for contract 123456 | CONTRACTS | contracts_by_contractnumber | EFFECTIVE_DATE | AWARD_NUMBER = 123456
Show me contract detials for 789012 | show me contract details for 789012 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, PAYMENT_TERMS, INCOTERMS | AWARD_NUMBER = 789012
When does contrat 456789 expire? | When does contrat 456789 expire? | CONTRACTS | contracts_by_contractnumber | EXPIRATION_DATE | AWARD_NUMBER = 456789, STATUS = EXPIRED
What's the experation date for 234567? | what's the expiration date for 234567 | CONTRACTS | contracts_by_contractnumber | EXPIRATION_DATE | AWARD_NUMBER = 234567
Get contarct informaton for 345678 | get contract information for 345678 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, PAYMENT_TERMS, INCOTERMS | AWARD_NUMBER = 345678
Whats the efective date for 567890? | whats the effective date for 567890 | CONTRACTS | contracts_by_contractnumber | EFFECTIVE_DATE | AWARD_NUMBER = 567890
Show contarct 678901 details | Show contarct 678901 details | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 678901
What is efective date of 789012? | what is effective date of 789012 | CONTRACTS | contracts_by_contractnumber | EFFECTIVE_DATE | AWARD_NUMBER = 789012
Get contract info for 890123 | get contract info for 890123 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, PAYMENT_TERMS, INCOTERMS | AWARD_NUMBER = 890123
Show me contarct 123456 | Show me contarct 123456 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 123456
effective date for 123456 | effective date for 123456 | CONTRACTS | contracts_by_contractnumber | EFFECTIVE_DATE | AWARD_NUMBER = 123456
show 789012 details | show 789012 details | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 789012
when does 456789 end | when does 456789 end | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 456789
234567 expiration | 234567 expiration | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 234567
345678 info | 345678 info | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 345678
567890 effective date | 567890 effective date | CONTRACTS | contracts_by_contractnumber | EFFECTIVE_DATE | AWARD_NUMBER = 567890
678901 contract details | 678901 contract details | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, PAYMENT_TERMS, INCOTERMS | AWARD_NUMBER = 678901
789012 expiry date | 789012 expiry date | CONTRACTS | contracts_by_contractnumber | EXPIRATION_DATE | AWARD_NUMBER = 789012
890123 start date | 890123 start date | CONTRACTS | contracts_by_contractnumber | EFFECTIVE_DATE | AWARD_NUMBER = 890123
123456 begin date | 123456 begin date | CONTRACTS | contracts_by_contractnumber | EFFECTIVE_DATE | AWARD_NUMBER = 123456
whos the customer for contarct 123456? | whos the customer for contract 123456 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 123456
customer name for 234567 | customer name for 234567 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 234567
what customer for contrat 345678? | what customer for contract 345678 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 345678
show custmer for 456789 | show customer for 456789 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 456789
customer detials for 567890 | customer details for 567890 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 567890
who is custommer for 678901? | who is customer for 678901 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 678901
get customer info for contarct 789012 | get customer info for contract 789012 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME, CONTRACT_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, PAYMENT_TERMS, INCOTERMS | AWARD_NUMBER = 789012
customer number for 890123 | customer number for 890123 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 890123
show custmer number for 123456 | show customer number for 123456 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 123456
what custommer number for 234567? | what customer number for 234567 | CONTRACTS | contracts_by_contractnumber | CUSTOMER_NAME | AWARD_NUMBER = 234567
payment terms for contarct 123456 | payment terms for contract 123456 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 123456
what are paymet terms for 234567? | what are payment terms for 234567 | CONTRACTS | contracts_by_contractnumber | PAYMENT_TERMS | AWARD_NUMBER = 234567
show payment term for 345678 | show payment term for 345678 | CONTRACTS | contracts_by_contractnumber | PAYMENT_TERMS | AWARD_NUMBER = 345678
payement terms for 456789 | payment terms for 456789 | CONTRACTS | contracts_by_contractnumber | PAYMENT_TERMS | AWARD_NUMBER = 456789
what payment for contrat 567890? | what payment for contract 567890 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 567890
incoterms for contarct 678901 | incoterms for contract 678901 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 678901
what incoterm for 789012? | what incoterms for 789012 | CONTRACTS | contracts_by_contractnumber | INCOTERMS | AWARD_NUMBER = 789012
show incotems for 890123 | show incoterms for 890123 | CONTRACTS | contracts_by_contractnumber | INCOTERMS | AWARD_NUMBER = 890123
contract lenght for 123456 | contract length for 123456 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 123456
what contract length for 234567? | what contract length for 234567 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 234567
price experation date for 123456 | price expiration date for 123456 | PARTS | parts_by_filter | EXPIRATION_DATE, PRICE | AWARD_NUMBER = 123456
when price expire for 234567? | when price expire for 234567 | PARTS | parts_by_filter | EXPIRATION_DATE, PRICE | AWARD_NUMBER = 234567, STATUS = EXPIRED
price expiry for contarct 345678 | price expiry for contract 345678 | PARTS | parts_by_filter | EXPIRATION_DATE, PRICE | AWARD_NUMBER = 345678
show price experation for 456789 | show price expiration for 456789 | CONTRACTS | parts_by_filter | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 456789
what price expire date for 567890? | what price expire date for 567890 | CONTRACTS | parts_by_filter | EXPIRATION_DATE, PRICE | AWARD_NUMBER = 567890, STATUS = EXPIRED
creation date for contarct 678901 | creation date for contract 678901 | HELP | HELP_CONTRACT_CREATE_USER | CONTRACT_NAME | 
when was 789012 created? | when was 789012 created? | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | 
create date for 890123 | create date for 890123 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 890123
show creation for contarct 123456 | show creation for contract 123456 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 123456
when created 234567? | when created 234567? | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | 
what type of contarct 123456? | what type of contarct 123456? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 123456
contract typ for 234567 | contract type for 234567 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 234567
show contarct type for 345678 | show contract type for 345678 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 345678
what kind contract 456789? | what kind contract 456789? | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 456789
type of contrat 567890 | type of contrat 567890 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 567890
status of contarct 678901 | status of contarct 678901 | CONTRACTS | contracts_by_contractnumber | STATUS | AWARD_NUMBER = 678901
what status for 789012? | what status for 789012 | CONTRACTS | contracts_by_contractnumber | STATUS | AWARD_NUMBER = 789012
show contarct status for 890123 | show contract status for 890123 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 890123
is 123456 active? | is 123456 active? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 123456, STATUS = ACTIVE
contract staus for 234567 | contract status for 234567 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 234567
show all details for 123456 | show all details for 123456 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 123456
get everything for contarct 234567 | get everything for contract 234567 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 234567
full info for 345678 | full info for 345678 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 345678
complete details contrat 456789 | complete details contrat 456789 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 456789
show summary for 567890 | show summary for 567890 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 567890
overview of contarct 678901 | overview of contarct 678901 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 678901
brief for 789012 | brief for 789012 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 789012
quick info 890123 | quick info 890123 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 890123
details about 123456 | details about 123456 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 123456
information on contarct 234567 | information on contarct 234567 | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | 
What is the lead time for part AE12345? | what is the lead time for part ae12345 | PARTS | parts_by_part_number | LEAD_TIME | INVOICE_PART_NUMBER = AE12345
Show me part detials for BC67890 | show me part details for bc67890 | PARTS | parts_by_part_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ | INVOICE_PART_NUMBER = BC67890
What lead tim for part DE23456? | what lead time for part de23456 | PARTS | parts_by_part_number | LEAD_TIME | INVOICE_PART_NUMBER = DE23456
Show leadtime for FG78901 | show lead time for fg78901 | PARTS | parts_by_part_number | LEAD_TIME | INVOICE_PART_NUMBER = FG78901
What's the leed time for part HI34567? | what's the lead time for part hi34567 | PARTS | parts_by_part_number | LEAD_TIME | INVOICE_PART_NUMBER = HI34567
Get part informaton for JK89012 | get part information for jk89012 | PARTS | parts_by_part_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ | INVOICE_PART_NUMBER = JK89012
Show part info for LM45678 | show part info for lm45678 | PARTS | parts_by_part_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ | INVOICE_PART_NUMBER = LM45678
What part details for NO90123? | what part details for no90123 | PARTS | parts_by_part_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ | INVOICE_PART_NUMBER = NO90123
Get part data for PQ56789 | get part data for pq56789 | PARTS | parts_by_part_number | PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = PQ56789
Show part summary for RS12345 | show part summary for rs12345 | PARTS | parts_by_part_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ, UOM, ITEM_CLASSIFICATION, STATUS | INVOICE_PART_NUMBER = RS12345
What's the price for part AE12345? | what's the price for part ae12345 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = AE12345
Show pric for part BC67890 | show price for part bc67890 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = BC67890
What cost for part DE23456? | what cost for part de23456 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = DE23456
Get price info for FG78901 | get price info for fg78901 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = FG78901
Show pricing for part HI34567 | show pricing for part hi34567 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = HI34567
What's the prise for JK89012 | what's the price for jk89012 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = JK89012
Cost of part LM45678 | Cost of part LM45678 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = LM45678
Price details for NO90123 | price details for no90123 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = NO90123
Show part price for PQ56789 | show part price for pq56789 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = PQ56789
What pricing for RS12345? | what pricing for rs12345 | PARTS | parts_by_part_number | PRICE | INVOICE_PART_NUMBER = RS12345
What's the MOQ for part AE12345? | what's the moq for part ae12345 | PARTS | parts_by_part_number | MOQ | INVOICE_PART_NUMBER = AE12345
Show minimum order for BC67890 | show minimum order for bc67890 | PARTS | parts_by_part_number | MOQ | INVOICE_PART_NUMBER = BC67890
What min order qty for DE23456? | what min order qty for de23456 | PARTS | parts_by_part_number | MOQ | INVOICE_PART_NUMBER = DE23456
MOQ for part FG78901 | moq for part fg78901 | PARTS | parts_by_part_number | MOQ | INVOICE_PART_NUMBER = FG78901
Minimum order quantity for HI34567 | minimum order quantity for hi34567 | CONTRACTS | parts_by_part_number | MOQ | INVOICE_PART_NUMBER = HI34567
What UOM for part JK89012? | what uom for part jk89012 | PARTS | parts_by_part_number | UOM | INVOICE_PART_NUMBER = JK89012
Show unit of measure for LM45678 | show unit of measure for lm45678 | PARTS | parts_by_part_number | UOM | INVOICE_PART_NUMBER = LM45678
UOM for NO90123 | uom for no90123 | PARTS | parts_by_part_number | UOM | INVOICE_PART_NUMBER = NO90123
Unit measure for PQ56789 | unit measure for pq56789 | CONTRACTS | parts_by_part_number | UOM | INVOICE_PART_NUMBER = PQ56789
What unit for part RS12345? | what unit for part rs12345 | PARTS | parts_by_part_number | UOM | INVOICE_PART_NUMBER = RS12345
What's the status of part AE12345? | What's the status of part AE12345? | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = AE12345
Show part staus for BC67890 | show part status for bc67890 | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = BC67890
Status for part DE23456 | status for part de23456 | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = DE23456
What status FG78901? | What status FG78901? | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = FG78901
Show part status for HI34567 | show part status for hi34567 | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = HI34567
Is part JK89012 active? | Is part JK89012 active? | PARTS | parts_by_part_number | PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = JK89012, STATUS = ACTIVE
Part status for LM45678 | part status for lm45678 | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = LM45678
What's status of NO90123? | What's status of NO90123? | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = NO90123
Show status for PQ56789 | show status for pq56789 | PARTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = PQ56789
Status info for RS12345 | status info for rs12345 | CONTRACTS | parts_by_part_number | STATUS | INVOICE_PART_NUMBER = RS12345
What's the item classification for AE12345? | what's the item item classification for ae12345 | PARTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = AE12345
Show item class for BC67890 | show item item classification for bc67890 | PARTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = BC67890
Classification for part DE23456 | item classification for part de23456 | PARTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = DE23456
What class for FG78901? | what item classification for fg78901 | PARTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = FG78901
Item classification HI34567 | item item classification hi34567 | CONTRACTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = HI34567
Show classification for JK89012 | show item classification for jk89012 | PARTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = JK89012
What item class for LM45678? | what item item classification for lm45678 | PARTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = LM45678
Classification of NO90123 | item classification of no90123 | CONTRACTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = NO90123
Item class for PQ56789 | item item classification for pq56789 | CONTRACTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = PQ56789
Show class for RS12345 | show item classification for rs12345 | PARTS | parts_by_part_number | ITEM_CLASSIFICATION | INVOICE_PART_NUMBER = RS12345
Show me invoice parts for 123456 | show me invoice parts for 123456 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 123456
What invoice part for 234567? | what invoice part for 234567 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 234567
List invoce parts for 345678 | list invoice parts for 345678 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 345678
Show invoice part for 456789 | show invoice part for 456789 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 456789
What invoice parts in 567890? | What invoice parts in 567890? | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 567890
Get invoice part for 678901 | get invoice part for 678901 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 678901
Show invoic parts for 789012 | show invoice parts for 789012 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 789012
List invoice part for 890123 | list invoice part for 890123 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 890123
What invoice parts for 123456? | what invoice parts for 123456 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 123456
Show all invoice part for 234567 | show all invoice part for 234567 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 234567
Show me all parts for contarct 123456 | show me all parts for contract 123456 | CONTRACTS | parts_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME | AWARD_NUMBER = 123456
What parts in 234567? | What parts in 234567? | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 234567
List part for contract 345678 | list part for contract 345678 | CONTRACTS | parts_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME | AWARD_NUMBER = 345678
Show parts for contrat 456789 | show parts for contract 456789 | CONTRACTS | parts_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME | AWARD_NUMBER = 456789
What parts loaded in 567890? | What parts loaded in 567890? | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
Get parts for contarct 678901 | get parts for contract 678901 | CONTRACTS | parts_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME | AWARD_NUMBER = 678901
Show all part for 789012 | show all part for 789012 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 789012
List parts in contract 890123 | List parts in contract 890123 | CONTRACTS | parts_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME | AWARD_NUMBER = 890123
What parts for 123456? | what parts for 123456 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 123456
Show part list for 234567 | show part list for 234567 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | AWARD_NUMBER = 234567
Show me failed parts for 123456 | show me failed parts for 123456 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
What failed part for 234567? | what failed part for 234567 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
List faild parts for 345678 | list failed parts for 345678 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 345678
Show failed part for 456789 | show failed part for 456789 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 456789
What parts failed in 567890? | What parts failed in 567890? | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
Get failed parts for 678901 | get failed parts for 678901 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 678901
Show failing parts for 789012 | show failing parts for 789012 | CONTRACTS | parts_failed_by_contract_number | AWARD_NUMBER, PART_NUMBER, PRICE, MOQ, UOM | LOADED_CP_NUMBER = 789012
List failed part for 890123 | list failed part for 890123 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 890123
What failed parts for 123456? | what failed parts for 123456 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Show all failed part for 234567 | show all failed part for 234567 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
Why did parts fail for 123456? | why did parts fail for 123456 | FAILED_PARTS | parts_failed_by_contract_number | REASON | LOADED_CP_NUMBER = 123456
Show error reasons for 234567 | show error reasons for 234567 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
What errors for failed parts 345678? | what errors for failed parts 345678 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 345678
Why parts failed in 456789? | Why parts failed in 456789? | FAILED_PARTS | parts_failed_by_contract_number | REASON | LOADED_CP_NUMBER = 456789
Show failure reasons for 567890 | show failure reasons for 567890 | FAILED_PARTS | contracts_by_contractnumber | REASON | LOADED_CP_NUMBER = 567890
What caused parts to fail for 678901? | what caused parts to fail for 678901 | FAILED_PARTS | parts_failed_by_contract_number | REASON | LOADED_CP_NUMBER = 678901
Error details for failed parts 789012 | error details for failed parts 789012 | FAILED_PARTS | parts_failed_by_contract_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ | LOADED_CP_NUMBER = 789012
Why failed parts in 890123? | Why failed parts in 890123? | FAILED_PARTS | parts_failed_by_contract_number | REASON | LOADED_CP_NUMBER = 890123
Show error info for 123456 | show error info for 123456 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON | LOADED_CP_NUMBER = 123456
What errors caused failure for 234567? | what errors caused failure for 234567 | FAILED_PARTS | contracts_by_contractnumber | REASON | LOADED_CP_NUMBER = 234567
Show me part errors for 123456 | show me part errors for 123456 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
What part error for 234567? | what part error for 234567 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
List parts with errors for 345678 | list parts with errors for 345678 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 345678
Show error parts for 456789 | show error parts for 456789 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 456789
What parts have errors in 567890? | What parts have errors in 567890? | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
Get parts errors for 678901 | get parts errors for 678901 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 678901
Show parts with issues for 789012 | show parts with issues for 789012 | CONTRACTS | parts_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 789012
List error parts for 890123 | list error parts for 890123 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 890123
What parts errors for 123456? | what parts errors for 123456 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Show all error parts for 234567 | show all error parts for 234567 | FAILED_PARTS | parts_failed_by_contract_number | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
What columns have errors for 123456? | what columns have errors for 123456 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Show error columns for 234567 | show error columns for 234567 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
Which columns failed for 345678? | which columns failed for 345678 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 345678
What column errors for 456789? | what column errors for 456789 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 456789
Show failed columns for 567890 | show failed columns for 567890 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
Error column details for 678901 | error column details for 678901 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON | LOADED_CP_NUMBER = 678901
What columns with errors for 789012? | what columns with errors for 789012 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 789012
Show column failures for 890123 | show column failures for 890123 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 890123
Which columns error for 123456? | which columns error for 123456 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Error column info for 234567 | error column info for 234567 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON | LOADED_CP_NUMBER = 234567
Show me parts with missing data for 123456 | show me parts with missing data for 123456 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
What parts missing info for 234567? | what parts missing info for 234567 | CONTRACTS | parts_by_contract_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ | LOADED_CP_NUMBER = 234567
List parts with no data for 345678 | list parts with no data for 345678 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 345678
Show incomplete parts for 456789 | show incomplete parts for 456789 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 456789
What parts missing data in 567890? | What parts missing data in 567890? | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
Get parts with missing info for 678901 | get parts with missing info for 678901 | CONTRACTS | parts_by_contract_number | INVOICE_PART_NUMBER, PRICE, LEAD_TIME, MOQ | LOADED_CP_NUMBER = 678901
Show parts missing data for 789012 | show parts missing data for 789012 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 789012
List incomplete parts for 890123 | list incomplete parts for 890123 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 890123
What parts no data for 123456? | what parts no data for 123456 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Show missing data parts for 234567 | show missing data parts for 234567 | CONTRACTS | parts_by_contract_number | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
What errors occurred during loading for 123456? | what errors occurred during loading for 123456 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Show loading errors for 234567 | show loading errors for 234567 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
What load errors for 345678? | what load errors for 345678 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 345678
Show loading issues for 456789 | show loading issues for 456789 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 456789
What happened during load for 567890? | what happened during load for 567890 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
Loading error details for 678901 | loading error details for 678901 | FAILED_PARTS | contracts_by_contractnumber | PART_NUMBER, ERROR_COLUMN, REASON | LOADED_CP_NUMBER = 678901
What load problems for 789012? | what load problems for 789012 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 789012
Show load failures for 890123 | show load failures for 890123 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 890123
Loading issues for 123456 | loading issues for 123456 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
What errors during loading for 234567? | what errors during loading for 234567 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
List validation issues for 123456 | list validation issues for 123456 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Show validation errors for 234567 | show validation errors for 234567 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
What validation problems for 345678? | what validation problems for 345678 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 345678
Show validation issues for 456789 | show validation issues for 456789 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 456789
What validation errors in 567890? | What validation errors in 567890? | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
Get validation problems for 678901 | get validation problems for 678901 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 678901
Show validation failures for 789012 | show validation failures for 789012 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 789012
List validation errors for 890123 | list validation errors for 890123 | FAILED_PARTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 890123
What validation issues for 123456? | what validation issues for 123456 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 123456
Show validation problems for 234567 | show validation problems for 234567 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 234567
Show me contarct details and failed parts for 123456 | show me contract details and failed parts for 123456 | FAILED_PARTS | parts_failed_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER, PAYMENT_TERMS, INCOTERMS | LOADED_CP_NUMBER = 123456
What's the effective date and part errors for 234567? | what's the effective date and part errors for 234567 | FAILED_PARTS | parts_failed_by_contract_number | EFFECTIVE_DATE | LOADED_CP_NUMBER = 234567
List all parts and customer info for contrat 345678 | list all parts and customer info for contract 345678 | CONTRACTS | parts_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, PAYMENT_TERMS, INCOTERMS | AWARD_NUMBER = 345678
Show contract info and failed part for 456789 | show contract info and failed part for 456789 | FAILED_PARTS | parts_failed_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER, PAYMENT_TERMS, INCOTERMS | LOADED_CP_NUMBER = 456789
Get customer name and parts errors for 567890 | get customer name and parts errors for 567890 | FAILED_PARTS | parts_failed_by_contract_number | CUSTOMER_NAME, CONTRACT_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, CUSTOMER_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON | LOADED_CP_NUMBER = 567890
Show contarct details and part issues for 678901 | show contract details and part issues for 678901 | CONTRACTS | parts_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, PAYMENT_TERMS, INCOTERMS | LOADED_CP_NUMBER = 678901
What effective date and failed parts for 789012? | what effective date and failed parts for 789012 | FAILED_PARTS | parts_failed_by_contract_number | EFFECTIVE_DATE | LOADED_CP_NUMBER = 789012
List contract info and error parts for 890123 | list contract info and error parts for 890123 | FAILED_PARTS | parts_failed_by_contract_number | CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS, INVOICE_PART_NUMBER, PRICE, MOQ, UOM, LEAD_TIME, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER, PAYMENT_TERMS, INCOTERMS | LOADED_CP_NUMBER = 890123
tell me about contract 123456 | tell me about contract 123456 | CONTRACTS | contracts_by_contractnumber | CONTRACT_NAME | AWARD_NUMBER = 123456
i need info on 234567 | i need info on 234567 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 234567
can you show me 345678 | can you show me 345678 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 345678
what do you know about contarct 456789 | what do you know about contarct 456789 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 456789
give me details for 567890 | give me details for 567890 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 567890
i want to see 678901 | i want to see 678901 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 678901
please show 789012 | please show 789012 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 789012
can i get info on 890123 | can i get info on 890123 | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 890123
help me with contract 123456 | help me with contract 123456 | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | 
i need help with 234567 | i need help with 234567 | HELP | HELP_CONTRACT_CREATE_USER |  | 
whats up with 123456? | whats up with 123456? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS, CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 123456
hows 234567 looking? | hows 234567 looking? | HELP | HELP_CONTRACT_CREATE_USER | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | 
anything wrong with 345678? | anything wrong with 345678? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS, CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 345678
is 456789 ok? | is 456789 ok? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 456789
problems with 567890? | problems with 567890? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 567890
issues with 678901? | issues with 678901? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | LOADED_CP_NUMBER = 678901
troubles with 789012? | troubles with 789012? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | AWARD_NUMBER = 789012
concerns about 890123? | concerns about 890123? | CONTRACTS | contracts_by_contractnumber | AWARD_NUMBER, PART_NUMBER, ERROR_COLUMN, REASON, LOADED_CP_NUMBER | AWARD_NUMBER = 890123
status on 123456? | status on 123456? | CONTRACTS | contracts_by_contractnumber | STATUS | AWARD_NUMBER = 123456
update on 234567? | update on 234567? | CONTRACTS | update_contract | AWARD_NUMBER, CUSTOMER_NAME, CUSTOMER_NUMBER, CREATED_DATE, EXPIRATION_DATE, STATUS, CONTRACT_NAME, CUSTOMER_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, STATUS | AWARD_NUMBER = 234567
